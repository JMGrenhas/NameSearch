# Ferramentas

## Flit
Cf. PyPI --> $ pip install -U flit
Para criar um projeto novo: $ flit init
Documentação flit: https://flit.readthedocs.io/_/downloads/en/latest/pdf/

(Para publicar o módulo no PyPI, com credenciais: $ flit publish)
