'''
  __init__.py
    @pt: Ponto de entrada no módulo NameSearch.
    @en: Entry point of NameSearch module.

  @pt: Destaques:
    Funções
      Name_List_Search
      Name_List_Search_unfolded

  @en: Highlights:
    Functions
      Name_List_Search
      Name_List_Search_unfolded
'''
__version__="0.1.3"

from .myNames import *
